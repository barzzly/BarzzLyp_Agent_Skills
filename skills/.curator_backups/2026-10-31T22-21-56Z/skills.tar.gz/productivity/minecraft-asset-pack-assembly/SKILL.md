---
name: minecraft-asset-pack-assembly
description: Use when assembling Minecraft plugin asset packs.
version: 1.0.0
metadata:
  hermes:
    tags: [minecraft, assets, itemsadder, modelengine, mythicmobs, mmoitems]
    category: productivity
---

# Minecraft Asset Pack Assembly

Build clean, deployable plugin data from vendor archives while preserving asset identities and plugin layout.

## Procedure

1. **Inventory before extraction**
   - List outer and nested ZIP members with Python `zipfile`; count files, unpacked bytes, top-level roots, and directory trees.
   - Treat each nested ZIP as one vendor package. Reject path traversal (`..` or absolute paths) before writing.
   - Inspect a known-good reference pack for structure only. Never copy its unrelated assets or runtime state into result.

2. **Choose deployable plugin variants**
   - Keep only plugin formats present in target stack, commonly `ItemsAdder`, `MMOItems`, `ModelEngine`, `MythicLib`, and `MythicMobs`.
   - Choose the installed resource provider before excluding alternatives: keep or convert Nexo-compatible definitions on Nexo servers; exclude Oraxen/Nexo only when another provider supplies equivalent assets. Vendor ItemsAdder/Oraxen/raw-pack variants can supply model, texture and icon mappings without installing those plugins. Omit documentation, macOS metadata and redundant archives from deployment.
   - For MythicMobs packages offering alternatives, select one compatible variant. Prefer explicit MMOItems/MMOCore damage variants over Crucible variants unless Crucible is requested.

3. **Normalize destination layout**
   - Put ItemsAdder namespaces under `ItemsAdder/contents/<namespace>/`; normalize legacy `ItemAdders` or namespace-only layouts.
   - Put ModelEngine sources under `ModelEngine/blueprints/`.
   - Put MMOItems definitions under `MMOItems/item/` and MythicLib skills under `MythicLib/skill/`.
   - If source MythicMobs contains `pack/` or `packs/`, place its contents under `MythicMobs/packs/`; never leave a separate top-level pack directory.
   - Put non-pack MythicMobs files under standard `items/`, `mobs/`, and `skills/` roots. Isolate package folders when filenames might collide.

4. **Merge without breaking identifiers**
   - Merge same-type YAML files only at document boundaries and preserve source comments for traceability.
   - When user wants one weapon registry, merge every weapon definition into `MMOItems/item/sword.yml` and remove now-empty type files; count semantic weapons by top-level YAML IDs, not source ZIP count.
   - Treat alternate/upgrade definitions as separate weapons unless user designates one as upgrade-only. If exact roster count is required, remove unwanted definition plus matching ItemsAdder item entry, model, and texture—not YAML alone.
   - For every weapon, cross-check MMOItems `material` + `custom-model-data` against ItemsAdder `resource.material` + `model_id`. Both fields form resource-pack predicate; mismatches can render another weapon's texture even when model JSON is correct.
   - If all weapons must share one base material, change that material consistently in MMOItems, ItemsAdder, and any MythicMobs item definition while preserving unique model IDs.
   - For custom sounds, resolve each MythicMobs `sound{s=...}` call against ItemsAdder `assets/<sound_namespace>/sounds.json`. Prefix event with namespace (`<namespace>:<event>`) when the JSON lives outside `assets/minecraft/`; an unqualified event otherwise resolves as vanilla namespace and stays silent.
   - Hash colliding binary/model files first. Drop byte-identical duplicates.
   - Never resolve differing `.bbmodel`, texture, sound, or YAML collisions by appending filename suffixes alone; configs usually reference original IDs, so renamed files become unreachable. Keep one only when assets intentionally share that ID. Otherwise isolate whole package and update every reference, or stop and report conflict.

5. **Clean and verify**
   - Remove empty directories, metadata, redundant nested ZIPs, docs, and unused plugin variants.
   - Assert expected top-level directories, no zero-byte files, no unexpected archives, no empty directories, and every MythicMobs pack path starts with `MythicMobs/packs/`.
   - Parse all YAML, parse every `.bbmodel` as JSON, and verify every retained custom sound event exists in its `sounds.json` under the namespace used by MythicMobs.
   - Assert requested weapon count from top-level keys in final MMOItems file, unique model IDs where required, and exact material/model-ID parity with ItemsAdder configs (see `references/rpg_pack_audit_matrix.md`).
   - Validate MMOItems ability cooldown keys: reject `skillcooldown:` in MMOItems ability blocks (which MMOItems ignores, falling back to 0.0s spam loops) and require standard `cooldown: <seconds>`.
   - Run combat rotation simulation across weapons (100s at 20 TPS) to catch runaway DPS (> 50 DPS on base tiers) and packet flood risks (> 25 packet events/sec).
   - Verify multi-phase boss encounters use persistent Aura phase locks (`duration=999999`) and `bulletType=DISPLAY` with bounded `md` ticks to protect server TPS.
   - Write machine-readable report containing source-package counts, semantic weapon count, final counts by plugin, skipped variants, collision policy, and unresolved conflicts.

6. **Package for delivery**
   - For plugin-folder bundles, ZIP the parent folder so extraction creates one named directory. For player resource packs, put `pack.mcmeta` and `assets/` directly at ZIP root; an enclosing project folder prevents Minecraft from loading the pack.
   - Run `ZipFile.testzip()` and verify archived file count equals staged file count before sending.

For MCPets mount packs, Nexo icon conversion and reload/delivery checks, read [Pet mount integration](references/pet-mount-integration.md).

For vendor boss collisions, generated textures, native spawn checks and delivery boundaries, read [Boss pack integration](references/boss-pack-integration.md).

For missing MMOItems abilities, modern MythicLib aliases and invisible PAPER animations, read [Weapon skill repair](references/weapon-skill-repair.md).

## Badge and glyph artwork previews

- For nametag overlap, inspect PNG alpha bounds before altering size. Full-height reconstructed glyphs with `ascent < height` extend below their row and collide with subsequent normal text; increasing ascent to unchanged height raises them while respecting vanilla `ascent <= height`. Padded artwork may need a small decrease instead. Compare each target in a native multiline TextDisplay, distinguish logo lettering from subsequent name/team rows, and reframe tall artwork rather than accepting cropped screenshots. Label isolated fixtures separately from live nametag-plugin verification.
- Rebuild compatibility from a freshly regenerated server ZIP when live assets changed; reapply only verified compatibility deltas from the fixed pack. Assert regeneration changes only intended font metrics, preserve textures/IDs and both model formats, and keep the 26.x text-font fix. Generation, local output, and public URL deployment are separate gates.

- For screenshot-only reconstruction, distinguish flattened RGB promotional previews from original RGBA textures before promising fidelity. Inventory every requested tag; preserve originals and label recovered textures as reconstructions. Occluded pixels and original alpha cannot be verified from flattened previews.
- If vision requests return HTTP 413, make a separate JPEG preview at at most 768 pixels on the longest edge, quality 80; retry that preview. For small details, use tightly cropped original-resolution regions instead of enlarging the full image. Never replace source files with reduced previews.

1. Resolve the exact target texture before drawing: tag and rank namespaces can contain identically named PNGs with different dimensions. Read source dimensions, RGBA alpha bounds, and glyph height/ascent when available; do not substitute the website wordmark for the in-game tag by filename alone.
2. Inspect the original at native size and an integer nearest-neighbor enlargement. Tiny stylized lettering is easily misread; confirm the actual letters before redesigning. Inspect current brand artwork separately for palette and style.
3. Preserve the requested canvas dimensions and transparency. Match apparent footprint and baseline as well as canvas size; check alpha bounds after downsampling because antialiasing can expand edges or clip bottom ornaments.
4. For Noesantara tag concepts, follow current requested lettering: user rejected generic block `NOE` and requested only `N`, with ornate detail comparable to original noetags. Prefer extracting/masking actual crystalline N from current logo over inventing a font. Use royal blue `#0038FF` with icy `#90E0F0` highlights and intricate ocean curls instead of feathers; avoid broad flat swooshes. Treat each revision as unapproved until user accepts.
5. Use Pillow for small deterministic artwork when sufficient: draw letter masks and sampled curves at higher resolution, apply gradients through masks, then downsample once with LANCZOS. Inspect the final native-sized PNG, not only the large working drawing; keep letter counters and dark separations legible.
6. Deliver a preview sheet with nearest-neighbor enlargement plus true-size samples on dark and light backgrounds. Label exact pixel dimensions and retain a separate transparent PNG; the opaque preview sheet is not the deployable texture.
7. When the user asks for preview first, stop after sending the preview. Do not upload, regenerate the resource pack, change glyph settings, or restart the server until separate installation approval. State clearly that the concept is not installed.

## Reconstructing badges from flattened promotional images

- Inventory and hash source bytes before processing; distinguish covers, detail screenshots, and actual transparent textures. Account for every requested label programmatically and verify ambiguous lettering with full-resolution crops rather than thumbnail OCR.
- When image inspection rejects large PNG payloads, create <=768px JPEG previews and separate small full-resolution detail crops. Keep sources untouched.
- Use guided silhouette masks plus selective scene-color removal; global sky/cyan keying can erase opaque pale ice and wing interiors. Restrict ambiguous color removal to silhouette edges, protect interiors, and inspect source-versus-cutout comparisons before accepting results.
- Preserve genuine detached ornaments. For translucent bubble rings, remove scene-filled centers but document uncertain rims; never invent hidden segments and call them recovered.
- Label chosen downsampled dimensions as reconstruction-native, not original vendor resolution. Retain high-resolution masked references, disclose omitted glow and edge-color uncertainty, and distinguish complete roster reconstruction from exact original recovery.
- Preview every asset at 1x and integer nearest-neighbor zoom on both light/dark backgrounds; size rows for the tallest sprite so preview clipping cannot masquerade as missing artwork. Verify RGBA alpha extrema, trimmed nonempty bounds, zero RGB under transparent pixels, config paths, source hashes, and archive member count/bytes.
- ItemsAdder font images use `contents/<namespace>/textures/font/<name>.png` with `font_images` entries containing `path: font/<name>.png`, `scale_ratio`, and `y_position`. Verify against current official docs. Large ornate badges need taller initial metrics than chat icons; document client-untested baseline and nametag integration separately. Do not assume ItemsAdder-assigned glyphs match a standalone vanilla font's codepoints.

## Real-client compatibility testing

- Test title and Options menu text, not only world glyphs/items. Nexo `rendertype_text.vsh` from 1.21.11 uses `texelFetch(Sampler2, UV2 / 16, 0)`; applying it to 26.1.2 (resource format 84.0) reproduces blank UI labels even on vanilla. Bound that legacy overlay to formats 75–76, matching the reference pack; 26.x then uses vanilla text shaders. Verify before/after on the same client and exact pack bytes. This disables that overlay's animated glyph effect on 26.x; do not claim Lunar validation from a vanilla test.

- Keep one graphical client active and record actual ZIP hash and ResourceManager reload stack per version. Declining a server pack tests local rendering only. Multiple accepted server packs can override candidate assets; verify downloaded bytes and precedence rather than assuming the newest request replaced old packs.
- Capture native plugin menus plus held item, readable scoreboard and actual summoned pet. A summon message or invisible base entity is not visual proof. Body-follow pets can stay outside first-person view; inspect third-person front view before changing pack/server settings. Distinguish missing model from camera position and pet configuration.
- Use exact `minecraft:tp` within `execute`; unqualified `tp` can resolve to Essentials. Clear chat input before typing after interrupted UI actions, and confirm actual menu state after each step.
- On low-memory software-rendering VPSs, test bounded client heap and one version at a time. Exit -9 proves forced termination, not OOM without kernel evidence. Do not count black screenshots or a launch helper's READY marker as gameplay success.
- Back up and update matching official ViaVersion/ViaBackwards versions before testing newly released clients; check ViaRewind compatibility too. Read fresh startup logs and active JAR hashes. A literal `${version}` in plugin metadata can defeat a version-string readiness check despite successful startup; report it and verify independently.

## Nexo COMPONENT migration and compatibility packs

- When migration is explicitly requested, back up settings, verify matching item equippable IDs and CustomArmor layer paths, switch to COMPONENT with a controlled restart, and wait for `Finished generating resourcepack!` separately from server `Done`. Read back settings and compare downloaded generated ZIP hash with the remote file.
- Prefer Nexo-generated equipment models/textures over reconstructed models. Merge only equipment changes into the previously verified compatibility pack so text/ModelEngine shader fixes survive. Validate humanoid and humanoid_leggings references under every active overlay; provide legacy `models/equipment` location for 1.21.2/1.21.3. Preserve original archives and report pre-existing unrelated warnings separately.
- Native COMPONENT armor requires Java 1.21.2+. Retaining legacy models, trims and pack-format ranges does not guarantee older clients can render translated component items. Never advertise all-version armor compatibility from metadata or ZIP tests. Generated server pack, complete local variants and public pack URL distribution are separate delivery states.

## Invisible worn armor diagnostics

- Compare freshly generated MMOItems armor with a minimal native item using the same equipment asset. A valid equipment JSON cannot help an item that lacks both `minecraft:equippable` and trim metadata; a fully transparent vanilla chainmail texture then makes its worn armor invisible. Confirm actual alpha extrema and capture both native-plugin failure and component-control rendering before changing production configs.
- Query modern entity `equipment.chest` before relying on legacy `Inventory[{Slot:102b}]`. An empty legacy query does not prove the armor slot is empty. Back up actual equipment before replacing test-player gear; preserve existing equipment even on disposable accounts.
- Copy candidate ZIP into the test client's resourcepacks directory and verify its hash. Unapproved symlinks can be rejected silently with a log warning, causing vanilla-only tests. Require ResourceManager reload to name the candidate.

- Read actual live equipment data before guessing armor identity from icons. Resolve `minecraft:equippable.asset_id` against the precise client pack, separately from inventory custom models and `minecraft:trim`. Restoring TRIMS does not erase equipment components already saved on items.
- For a missing equipment model with existing full-color armor textures, test a small additive ZIP above the original pack. Supply `assets/<namespace>/equipment/<id>.json` for 1.21.4+ and `assets/<namespace>/models/equipment/<id>.json` for 1.21.2/1.21.3, with humanoid/humanoid_leggings textures under their matching `textures/entity/equipment/` paths. Preserve original bytes, item data and legacy trim assets; validate every layer reference and ZIP CRC. Do not generalize a single set fix to every armor set.
- Separate reference-resolution success from client rendering. Missing assets are concrete evidence; server readiness, warning disappearance, and static ZIP tests do not prove visible armor. Ask for exact client version and active pack precedence if the isolated patch still fails. Do not launch a graphical Minecraft client on a capacity-constrained VPS against the user's standing restriction.

## Kit armor naming and enchant parity

- Derive armor collection name and exact gradient from the matching live `MMOItems/item/kit_*.yml` collection lore; do not reuse stale armor names or invent colors. Map Nexo armor through explicit `mmoitem.type: ARMOR` and `mmoitem.id`, update MMOItems `base.name`, and mirror Nexo `itemname`. Keep cosmetics separate.
- When requested to enchant armor to pack tier, inspect existing weapon/tool enchant levels in that pack. Use armor-valid enchant types by slot, not weapon enchants; disclose unsafe higher levels inherited from pack. Preserve IDs, material/CMD, gems, combat stats, trim and equipment components unless separately authorized.
- Save complete roster and before/readback snapshots, count all sets and pieces, and leave a runnable semantic YAML check permitting only requested fields. Nexo can rewrite formatting at boot; compare parsed values before reporting unintended changes. Existing player/crate item snapshots are not automatically migrated by editing templates.

## Nexo material and model-ID lookup

1. Confirm the live target server, then recursively read `.yml`/`.yaml` under the requested Nexo category; for kits, use `plugins/Nexo/items/Kits/`. Use read-only SFTP/API and parse YAML rather than trusting stale local snapshots or filename matches.
2. Filter top-level item definitions by exact `material`. Return `itemname`, top-level Nexo ID, `Pack.custom_model_data`, `Pack.model`, and containing kit/file. Treat absent fields as absent; do not infer allocated CMD from a folder label such as `Model <number>`.
3. Count scanned files and matching definitions programmatically before claiming “only one” or listing all matches. Report compact bullets with target server and distinguish configured CMD from live-item/rendering verification. No reload or server mutation is needed for this lookup.

## Standing Rules

- **Server Content & Asset Roster Auditing (NoeRPG / Nexo Stack)**:
  When auditing content counts (RPG packs, legendary weapons, bosses, pets, cosmetics, tags):
  1. **Source of Truth**: Count custom assets defined in the resource pack and primary content plugins (Nexo, ModelEngine, MCPets, MMOItems, MythicMobs).
  2. **Exclude Procedural & Vanilla Cosmetics**: Do not count UltraCosmetics vanilla particle effects, suits, or procedural pets into custom cosmetic pack totals unless specifically asked.
  3. **Tags Scoping**: Count custom font glyph tags (Nexo `plugins/Nexo/glyphs/`) as custom tags; exclude text-only chat prefix/title plugins (e.g. DeluxeTags) unless chat titles are explicitly requested.
  4. **RPG Packs**: Count full item/armor sets configured under `Nexo/items/Kits/` or `MMOItems/item/kit_*.yml`.

- For three-mode resource-pack requests, use HDResourcePack, OPResourcePack and SPResourcePack with the established blue descriptions. Distinguish metadata-only copies from actual optimization; preserve source, keep HD quality intact, use lossless OP changes, and get explicit permission before reducing SP texture quality. Read [Named pack variants](references/named-pack-variants.md) and [Compression](references/audio-pack-compression.md) for build and verification details.

- User wants finished folder shaped like working reference pack, not copied reference assets.
- For pet packs, name matching Nexo and ModelEngine parent folders `<Pack> ( Brick Model <min>-<max> )`, using actual allocated Nexo CMD bounds. Inspect live neighboring folders first; preserve pet IDs, model IDs and blueprint filenames when renaming.
- For cosmetic packs on the NoeRPG Nexo stack, unify base material to `COAL`: assign sequential CustomModelData continuing from the server's highest existing COAL CMD (e.g. 1102 -> 1103-1134, 1135-1149). Name parent folders and files `plugins/Nexo/items/Cosmetics/Cosmetics_<PackName> ( Coal Model <max_cmd> )/Cosmetics_<PackName> ( Coal Model <max_cmd> ).yml`. Strip vendor dye `color:` fields because COAL is non-dyeable; add `Mechanics.hat.enabled: true` to any head/hat/beret item. When vendor zips bundle multiple plugin variants (HMCCosmetics, Oraxen, CosmeticsCore), deploy only the Nexo configs and assets under `plugins/Nexo/pack/external_packs/Noesantara/assets/<namespace>/`.
- For trading/gacha card packs on the NoeRPG Nexo & MythicMobs stack:
  1. **Unify base material to `LAPIS_LAZULI`**: All cards and booster packs use `material: LAPIS_LAZULI` in Nexo and `Id: LAPIS_LAZULI`, `Furniture.Material: LAPIS_LAZULI` in MythicMobs.
  2. **Sequential CustomModelData continuing from server allocation**: Allocate CMD sequentially starting from 1 (or continuing from highest existing LAPIS_LAZULI CMD). E.g. Pack 1 CMD 1–39, Pack 2 CMD 40–77.
  3. **Folder and file naming**: Place under `plugins/Nexo/items/Gacha Card/`. Name parent folder and consolidated YAML: `plugins/Nexo/items/Gacha Card/GachaCard_<PackName> ( Lapis Model <max_cmd> )/GachaCard_<PackName> ( Lapis Model <max_cmd> ).yml`.
  4. **Nexo Model Identifier**: Set `Pack.generate_model: false` and prefix model paths with explicit namespace `Pack.model: <namespace>:cards/...` (bare `<namespace>/...` without colon resolves to `minecraft:<namespace>/...` and breaks on external packs).
  5. **Resource Pack Placement**: Extract models to `plugins/Nexo/pack/external_packs/Noesantara/assets/<namespace>/models/cards/` and textures to `.../textures/cards/`. Models from vendor RP zip already include `<namespace>:cards/...` texture paths; verify model JSON texture references use explicit namespace.
  6. **MythicMobs Pack Parity**: Deploy to `plugins/MythicMobs/packs/GachaCard_<PackName>/` with `items/`, `mobs/`, `skills/`, and `packinfo.yml`. Match `Model: <CMD>` and `Furniture.Model: <CMD>` to Nexo `custom_model_data`. Mobs use `ItemHead: <item_id>` and skills run `nexo give <item_id> 1 <target.name>`. Omit duplicate shared entries (e.g. `nm_card_back`, `nm_card_preview_back`, `nm_card_animation_back`) from subsequent packs to prevent duplicate registry warnings.
  7. **Fast Atomic Remote Sync via SFTP Batch**: For multi-folder pack deployments (hundreds of textures/models), use `sftp -b` with `put -r` (e.g. `sftp -P 60002 -o BatchMode=yes -o StrictHostKeyChecking=no -b <batch_file>`) rather than slow sequential API uploads or unsupported container archive extraction. Verify live with `nexo reload items` and `mm reload`.
  8. **Blockbench 2D Model `#missing` and Atlas Invariant**: Flat card models often contain zero-thickness side faces (`east`, `west`, `up`, `down`) referencing `#missing`. Strip those zero-area faces and define fallback `"missing": "<namespace>:cards/admin/nm_card_back"` in the `"textures"` block to prevent in-game magenta/black missing textures. Ensure all card texture paths are registered as `single` sources in root `assets/minecraft/atlases/blocks.json` and overlay atlases (`nexo_1_21_11/.../blocks.json`).
  9. **Custom Lore Hierarchy for Collectible Cards**:
     - Format: leading blank line `- ''`, `Rarity: <color><bold><TIER></bold>`, `Series: <color><SeriesName></color>`, blank line `- ''`, `<dark_gray>» <gray>Kartu Koleksi Gacha`, and `<dark_gray>» <gray>Dapat dipajang di dinding`.
     - Tiers: `BASIC` (`<white><bold>` / `&f&l`), `RARE` (`<aqua><bold>` / `&b&l`), `ULTRA-RARE` (`<light_purple><bold>` / `&d&l`), `SPECIAL` (`<dark_red><bold>` / `&4&l`).
     - Booster Packs: Preserve original opening instructions and drop rates (`if 'pack' in item_id: do not overwrite lore`).
     - MythicMobs Parity: Mirror exact lore lines using Minecraft formatting codes (`&7`, `&f&l`, `&b&l`, `&d&l`, `&4&l`).
- When vendor packs bundle both pet mounts and combat bosses (e.g. Samus Dragon Pack): strictly isolate pet content from boss content. Place mount icons in `plugins/Nexo/items/Pets/<Pack> ( Brick Model <min>-<max> )/` and any boss items in `plugins/Nexo/items/Boss/`. Place mount mobs and dash/flight skills in `plugins/MythicMobs/{mobs,skills}/Pets/<Pack>/`, and world bosses (bossbars, phases, minions, totem statues) in `plugins/MythicMobs/{mobs,skills}/Boss/BOSS_<Pack>/`. Place `.bbmodel` blueprints under `plugins/ModelEngine/blueprints/PETS/<Pack ( Brick Model <min>-<max> )>/`; never duplicate them into `blueprints/BOSS/` because ModelEngine scans recursively and rejects duplicate blueprint IDs. Namespace vendor generic helper skills (`Cancelattack`, `Changetarget`) to `<Pack>_Cancelattack` to avoid server-wide skill collisions.
- For reported slow resource-pack downloads, separate ZIP integrity/size from live HTTP distribution: inspect actual `server.properties` URL and SHA-1, test HTTP response/TTFB/range and bytes, then compare served bytes to local artifact. A smaller local ZIP does not fix a stale/404 public URL, and high entry count can affect client parsing independently of transfer time. Audit `optimized-pack.zip` against the current source before assuming its name means it is complete: a ZIP can pass CRC while missing assets, resizing bitmap fonts/animations/equipment, and turning ordinary ModelEngine textures into shader-sensitive 64×64. Build a separate safe candidate from complete current SP, with standard DEFLATE and preserved payloads, and keep old target as backup; report a bigger but complete result honestly. Do not claim download-speed fix without an end-to-end test from client network.
- When replacing player-facing pack links in a live DeluxeMenus pick-pack menu, identify the exact target server and read its active `plugins/DeluxeMenus/gui_menus/menupack.yml`, not a local snapshot. Dropbox links shared by users typically end with `dl=0` (HTML preview); always transform to `dl=1` for direct ZIP download in click commands. Probe each supplied URL with a byte-range GET: require ZIP magic and inspect `Content-Range` total; a Dropbox `dl=1` link can redirect to HTML or differ from local ZIP size. Back up remote YAML, replace only the three URL substrings in the corresponding HD/OP/SP click commands, parse YAML and assert every other menu field unchanged, then POST the exact bytes through Pterodactyl `files/write`. Read back the same remote path byte-for-byte, issue `dm reload menupack` without restarting, and require `menupack menu successfully reloaded!` in fresh console log. If menu display names/lore contain sizes, compare them with measured hosted sizes and disclose stale labels unless size edits were requested; do not confuse changing manual menu links with changing automatic `server.properties` pack.
- Treat “allversion like before” as a fresh-server pack rebuild with the previously verified, explicitly bounded compatibility patches—not support for every Minecraft version. When user asks to make `pack.zip` "all version bener bener all version model engine dll nya" using `ALL_VER.zip` as reference:
  1. **Nexo Generation Reset Pitfall**: Fresh server Nexo pack generation resets `pack_format: 75`, removes modern `modelengine_26_3/` shaders, unbounds overlays with `max_format: 32767`, omits 1.20.1 root `player_head.json`, omits `assets/nexo/models/equipment/` aliases, and overwrites the 26.3+ single-atlas invariant (`rank_lv50/bone.json` multi-atlas crash).
  2. **All-Version Asset Base**: Use `ALL_VER.zip` as base containing all-version metadata (`pack_format: 15`, `supported_formats: [15, 97]`, bounded overlays with `nexo_1_21_11` capped at format 76, modern `modelengine_26_3` shaders, root `player_head.json`, 16,661 `leather_horse_armor.json` ModelEngine overrides, and single-atlas blocks registrations). Graft all newly added server assets (e.g. Gacha Card models/textures, dual `lapis_lazuli.json` items/models, and new model textures) onto this base.
  3. **Three-Mode Variants Generation (`HD`, `OP`, `SP`)**: Run `build-three-modes.py` to produce `HDResourcePack.zip` (original asset bytes), `OPResourcePack.zip` (lossless PNG/JSON compaction), and `SPResourcePack.zip` (compressed audio and lossy texture preset from prior build). Never apply lossy compression to newly added or modified assets. Verify `testzip()` and JSON/MCMETA syntax across all three archives.
- Read active `server.properties` resource-pack URL and download/CRC-check its actual bytes: a valid local ZIP does not repair a stale or corrupt public ZIP. Separately check ModelEngine runtime errors (`ItemModelData$SubModel.getItem() is null` during bone stack creation) and Nexo generation completion; resource-pack edits cannot fix a server-side item allocation failure. For suspected ModelEngine server changes, page Pterodactyl client `/activity?per_page=100&page=<n>` across incident window; correlate upload/write/console/power events with first error in archived `logs/*.log.gz`, not only `latest.log`. Compare live config/JAR bytes with backups and cache IDs by key (added/removed/reassigned); reload mtime or temporal proximity alone does not prove root cause or actor. Keep audit read-only. Never regenerate or restart a crowded production server on speculation.
- User prefers one consolidated `MMOItems/item/sword.yml` for this weapon-pack class; preserve only explicitly requested roster entries.
- When sending a fix-only archive, include only files actually changed plus unavoidable shared registries; do not resend every asset for that class unless user requests a standalone ready-to-install pack.
- Delete unused raw/vendor alternatives from final output; keep original source archives untouched unless explicitly asked.

## Nexo Custom Material Definitions and Live Reloading

- When transforming unconfigured vendor pack items (e.g. `plugins/Nexo/items/Material/Material_PixelMine ( Sugar Model 1204 )/`):
  1. **Rename key directly**: Rename the top-level YAML key (e.g. `charred_skull` -> `charm_skull`, `bat_wing` -> `bat_fragment`, `spirit_mask` -> `ruka_ragnamok`) rather than duplicating keys with identical `Pack.custom_model_data`. Nexo emits duplicate CustomModelData warnings on reload if multiple IDs share the same base material and model ID.
  2. **Gradient and Smallcaps Display Name**: Use Adventure MiniMessage gradients with unicode smallcaps: `itemname: "<gradient:#hex1:#hex2>sᴍᴀʟʟᴄᴀᴘs</gradient>"`.
  3. **Lore Format**: Standardize lore with a leading blank line `- ''` followed by gray prefix `§7` and smallcaps unicode text lines.
  4. **Command Syntax**: Use `/nexo give <item> [amount] [player]` (item ID is the first argument, followed by quantity, then player).
  5. **Live Reloading**: Execute console command `nexo reload items` for live updates in milliseconds with zero server restart and zero TPS loss.

- Prefer deterministic Python `zipfile` processing over manual extraction for nested archives, path safety, counting, and verification.
- Cross-verify the actual integration chain before deployment: weapons using MMOItems/ItemsAdder/MythicLib/MythicMobs need material/CMD parity and numeric cooldown checks; pets using MCPets/Nexo/MythicMobs/ModelEngine need root and skin icon mappings, mob/skill references, blueprint IDs and generated assets checked. Do not require absent plugins to validate an unrelated pack class.
- **Multi-Version Resource Pack & ModelEngine Overlay Compatibility (1.20.1 to 26.x+)**:
  - Minecraft 1.20.1 (`pack_format: 15`) does not support `overlays` in `pack.mcmeta` (introduced in 1.20.2 / `pack_format: 18`); vanilla 1.20.1 clients strictly ignore overlays and read only root `assets/`. When ModelEngine places item overrides (e.g. `player_head.json`) inside an overlay directory like `modelengine_1_19_4/`, copy it directly to root `assets/minecraft/models/item/player_head.json` so 1.20.1 clients load model definitions without errors.
  - Use `pack_format: 15` for 1.20.1 plus legacy `supported_formats` and modern `min_format`/`max_format` bounded to actual targets. Declaring 32767 only suppresses compatibility warnings; it does not guarantee future rendering. Never leave legacy ModelEngine overlays (e.g. `modelengine_26_1`, `modelengine_26_2`) unbounded with `max_format: 32767`—bound each overlay strictly below the version introducing breaking shader syntax (e.g. `modelengine_26_1` bounded to format 87, `modelengine_26_2` bounded to format 96) so modern clients (26.3 / format 97+) do not load deprecated `#moj_import` shaders.
  - Port modern shader overlays from the exact target's official vanilla shaders, preserving OIT, glint, explicit attribute locations and game includes. Java 26.3 release uses resource format 97.1; its shaders use `#include` and `gl_VertexIndex`, not legacy `#moj_import`/`gl_VertexID`. Transplant only ModelEngine-specific displacement/fading and verify actual client pipeline compilation; compilation alone does not prove entity rendering. Never label a candidate complete until live items, pets and fonts are visually checked.
  - **Item Model Single-Atlas Invariant (26.3+)**: In Minecraft 26.3+, `CuboidItemModelWrapper.validateAtlasUsage` strictly enforces that all quads in any baked item model belong to a single texture atlas (`items.png` OR `blocks.png`). Never mix `item/` textures (items atlas) with `entity/models/` or block textures (blocks atlas) within the same model JSON (e.g. `rank_lv50/bone`). When an item definition uses `range_dispatch` (e.g. `leather_horse_armor.json`), a single child model failing this check throws `IllegalStateException: Multiple atlases used in model` and causes the client to fail baking the entire parent item model, rendering all 16,000+ ModelEngine entity models completely invisible. For emerald rank bone, replace `rank_badge:item/rank_badge/emerald_rank` with the byte-identical existing `rank_badge:rank_badge/emerald_rank`; for `bone2`, copy `emerald_rank_blank.png` to `textures/rank_badge/` and register its new path in root `atlases/blocks.json`. Assert only one atlas across *actual face references*, not every unused texture key. Generated pack may overwrite this on regeneration, so reapply after fresh server build.
  - Always maintain dual item model formats in the pack root: `assets/minecraft/models/item/<item>.json` (predicate overrides with `custom_model_data` for 1.20.1 - 1.21.3 clients) alongside `assets/minecraft/items/<item>.json` (data-driven format for 1.21.4+ clients). Skipping either breaks rendering for that client range. When bounding older ModelEngine overlays, preserve `modelengine_1_21_6/assets/modelengine/items/player_head.json`'s `special.player_head` renderer at root for 26.x: newer generated root may use `special.head`/`kind: player` instead, and losing old overlay changes skin behavior. Compare effective overlay files per target version, not just overlay counts.
