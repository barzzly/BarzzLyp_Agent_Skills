---
name: discord-bot-operations
description: "Use when changing Discord bot embeds or PM2 deployment."
version: 1.0.0
license: Apache-2.0
platforms: [linux]
metadata:
  hermes:
    tags: [discord, bot, embeds, webhooks, pm2, nodejs]
    category: social-media
---

# Discord Bot Operations

## Standing rules

- Keep embed branding consistent across commands, panels, webhooks, and logger-generated messages; do not patch only the command named by the user when the requirement is global.
- Distinct branding scopes:
  * For player-facing Noesantara embeds: keep footer branding to `Noesantara Network` and use Discord's native timestamp (`setTimestamp()` / ISO `timestamp`) as the only date display; use fixed blue Noesantara logo URL `https://store.noesantara.id/logo-no-backround.png`.
  * For private developer / infrastructure sentinel bots (e.g. `BarzzLyDev Bot`): keep branding to `BarzzLyDev`, footer `BarzzLyDev • MM/DD/YYYY hh:mm AM/PM` (WIB / Asia/Jakarta) with BarzzLyDev icon, title `BarzzLyDev ...`. Never mix Noesantara Network branding into BarzzLyDev admin/sentinel tooling. Omit the top `setAuthor()` header if the bot user header already displays the bot name. Avoid cluttering fields/status with emoji spam (like ✅/❌/🚀/🏁); keep at most one clean functional icon (e.g. `📦`) in the title and clean text for status (`Berhasil` / `Gagal`).
- Spacing before footer in Discord embeds: never add an entire blank field (`{ name: '\u200B', value: '\u200B' }`) for footer separation because Discord renders fields with large vertical padding. Append a single newline with zero-width space (`\n\u200B`) to the value of the final field to produce exactly a 1-line vertical gap above the footer.
- Dual-mode execution for CLI tools hosted in Pterodactyl containers: Pterodactyl server containers invoke the main script without CLI flags on startup. Scripts designed for CLI logger duties must detect missing flags and stay alive in a lightweight idle daemon state (logging ready and setting bot presence activity) instead of exiting with error, preventing Pterodactyl crash-loops while remaining invocable via CLI.
- Pterodactyl startup regex matching for bot containers: Pterodactyl Wings marks a container as `running` (green) only when console stdout matches the egg's `config_startup.done` regex (e.g. `Bot aktif sebagai`). If a bot logs a custom ready message without emitting the expected string in `on_ready()` or wrapper launchers, the server remains stuck in `starting` (yellow status badge) despite being online on Discord. Ensure the startup log matches the egg's `done` pattern.
- For CLI/cron logger bots using Bot User accounts (not webhooks): instantiate lightweight `Client` with minimal intents (`GatewayIntentBits.Guilds`), fetch destination channel via `channels.fetch(id)` with cache fallback, send embed, and cleanly teardown via `await client.destroy(); process.exit(0)`. In discord.js v14+, listen to `Events.ClientReady` and attach an unreferenced hard timeout (`setTimeout(() => fail(), 30_000).unref()`) so cron/backup pipelines never hang on network partitions.
- When users ask to restore or match an existing panel, treat the current Discord message as the source of truth: inspect its description, emoji IDs, button labels/URLs, mention content, footer, and image fields before rebuilding; product catalog data alone is not enough.
- Use the fixed blue Noesantara logo URL `https://store.noesantara.id/logo-no-backround.png` as footer `icon_url`; never fall back to bot avatar when branding requires the Noesantara logo.
- When refreshing an existing panel, preserve its established visual language: exact emoji, list layout, buttons, `@everyone`, and footer branding. Apply the requested casing consistently to product labels in overview, select options, and detail embeds (not just one visible row); preserve product IDs, option values, prices and copy unrelated to the request. Inspect the previous builder/source and live message before rebuilding; never invent a plain replacement from product data.
- For user-facing reward/pass embeds, omit internal mechanics (permission nodes like `lp user ...`, internal activation commands, and database flags) unless requested; present player-facing guidance instead (e.g. `• **Cara Pakai:** Ketik \`/command\` di ingame`).
- In Indonesian copy for Noesantara bot, write `ingame` without hyphen (never `in-game`). Use dedicated animated guild emojis (such as `<a:goldencoinspin:1258157813746897000>` for Coin Pass) in titles.
- Existing Discord messages do not change retroactively. For text/option changes or retroactively fixing already-sent log/panel embeds across guild channels, query candidate channels via Discord REST (`GET /channels/{id}/messages`), identify the exact bot-authored embeds, and PATCH them in place (`PATCH /channels/{id}/messages/{id}`) without deleting messages or sending duplicate notifications. When asked to delete an old panel and send a new message, delete only that specific panel. Never delete every recent bot message: other panels may share the channel.
- Keep secrets in `.env`; never print tokens, API keys, or webhook keys in logs or reports.
- Prefer the smallest centralized change over repeating footer/timestamp code in every command.

## Procedure

1. Locate every embed producer before editing. Include command files, interaction handlers, webhook servers, donation loggers, and panel builders.
2. Add one centralized embed metadata helper or a single serialization boundary. Apply organization footer and native send timestamp at final serialization so future commands and webhook paths cannot bypass branding. Do not add a second human-readable date to footer: Discord's native timestamp already renders relative day label and rolls over to calendar date automatically.
3. Preserve the fixed Noesantara logo in the final footer object; replace stale organization text rather than appending a second footer. Use `Asia/Jakarta` time and an ISO timestamp for Discord's native timestamp. Remove panel-specific decorative images when requested, but keep footer logo independent from embed body images. For raw payload embeds, explicitly include footer, icon, timestamp, components, and allowed mention fields because they bypass `EmbedBuilder` serialization hooks.
4. Run syntax checks across all changed JavaScript:
   ```bash
   node --check index.js
   for f in commands/*.js donation-logger.js webhook-server.js items-handler.js rank-handler.js; do node --check "$f" || exit 1; done
   ```
5. When adding or modifying slash commands, register guild commands with `node deploy.js` so Discord updates the command definitions immediately without waiting for global cache propagation.
6. For temporary Discord role assignments (e.g. 7-day passes), track grant and expiration timestamps in a persistent JSON store; check and remove expired roles on bot startup and via a periodic `setInterval` (e.g. 60s). Never use in-memory `setTimeout` alone. For stackable/queued passes, store an array of discrete pass records (`status: 'active' | 'remaining' | 'expired'`, `channelId`, `messageId`); never key the store by `userId` alone, because repeat purchases overwrite active passes and drop message tracking. When an active pass exists for the same player and user, mark the new pass `remaining` and defer RCON execution until promotion. On expiration, patch the old embed to `expired`, promote the next `remaining` pass to `active`, execute its RCON/pass reset, patch its embed, and revoke the Discord role only when zero active passes remain for that user. When zero passes remain in queue, dispatch in-game revocation via RCON (e.g. `weeklypass <passId> disacc <nick>`).
7. For in-game passes with repeat/queued cycles (e.g. NoeWeeklyPass):
   - Never rely on `/weeklypass <passId> acc <nick>` alone to activate queued or repeat passes; plugins that keep existing start dates and claim records will either reject with `already-authorized` or keep the old cycle intact, preventing claims on day 1.
   - Resolve the player UUID via RCON `papi parse <nick> %player_uuid%`.
   - Reset the player file directly via Pterodactyl Client API (`POST /api/client/servers/{id}/files/write`) with `start: today`, `authorized: true`, and empty claims `{}`.
   - Flush the plugin's in-memory cache (e.g. send 520 dummy UUID queries via RCON to overflow a 512-capacity LRU cache) so runtime in-game menus reload from disk immediately without requiring a Minecraft server restart.
8. For in-game RCON commands triggered by Discord interactions, strip leading `/` from console commands, ensure `rcon.end()` runs in a `finally` block to prevent lingering socket connections, and append executed actions to `rcon-log.txt`.
9. Run one serialization self-check that constructs an `EmbedBuilder` and asserts footer text is exactly `Noesantara Network` and native timestamp exists. Avoid starting a second bot instance because its webhook port can collide with PM2.
10. Restart only intended PM2 process and verify liveness:
   ```bash
   pm2 restart <bot-name> --update-env
   sleep 3
   pm2 describe <bot-name>
   pm2 logs <bot-name> --lines 30 --nostream
   ```
   Require `status: online`, `unstable restarts: 0`, and a ready log before reporting success.
11. For panel refreshes, keep channel IDs in one small sender script, target only requested channels, delete only bot-authored messages, send item/rank/coin payloads, and avoid starting a second long-lived bot process. Build Coins from the existing panel convention or source-of-truth product builder, including its coin emoji/list/description and `Webstore Noesantara` link; omit only the body image when requested while retaining footer logo. Add `content: '|| @everyone ||'` when the panel convention requires a visible everyone mention, then verify it through the API. Never replace a rich existing panel with a minimal placeholder just because the catalog is available.
12. Check source for stale branding and inspect `git diff --check`. Report changed scope, runtime status, message IDs verified, and that unrelated human messages were preserved.

## RCON migration

- Resolve ambiguous ECO RPG labels against exact old/new panel server identifiers before changing the bot. Match target RCON allocation and active `server.properties` password; preserve other bot env keys and back up `.env` with owner-only permissions.
- Inspect PM2 RCON override key names without printing secrets. If no overrides exist and bot loads dotenv, restart only intended bot without `--update-env`; verify a fresh Discord ready log and `unstable_restarts: 0`.
- Recheck target power state immediately before final verification; earlier offline state may have changed. When running, use bot's installed `rcon-client` to authenticate and send read-only `list`, then close connection. TCP reachability alone does not prove password authentication. Never start a second Discord bot instance for this check.

## Pitfalls

- Do not assume `/weeklypass <passId> acc <player>` resets an in-game pass for a repeat purchase or queue promotion; custom pass plugins that store YAML per player and cache progress in memory will reject with `already-authorized` or preserve the previous `startDate` and completed claims, blocking day 1 claims. Always rewrite the player YAML with `start: today` and `claims: {}` via Pterodactyl Client API and flush the plugin's in-memory LRU cache before player opens the menu.

- Do not rely on in-memory `setTimeout` for temporary Discord role assignments; PM2 reloads and process restarts discard in-memory timers, permanently orphaning expired roles on users. Use a persistent JSON store with a startup and interval check.
- Do not key temporary pass stores by `userId` alone when passes can stack; repeat commands will overwrite active entries, discard earlier queue timers, and orphan Discord message IDs needed for retroactive status patches.
- Do not leave RCON client sockets open or unhandled on exceptions; always place `rcon.end()` inside a `finally` block to prevent socket exhaustion.
- Do not prefix console commands with `/` in Minecraft RCON; console dispatchers expect bare command names and will fail or behave unpredictably.
- Do not forget to run `node deploy.js` when adding or modifying slash commands; Discord does not register new commands in the guild until `applicationGuildCommands` is updated.
- Do not add footer logic only to a shop panel when the requirement covers every embed; donation, announcement, moderation, utility, webhook, and future embeds use separate construction paths.
- Do not run `node index.js` as a verification probe while PM2 bot is online; the real webhook listener already owns its port and the probe exits with `EADDRINUSE`.
- Do not claim a PM2 restart succeeded from exit code alone; read process status and recent logs because a crash-loop can briefly report a successful restart.
- Do not use a second `setFooter()` after a centralized serialization hook unless intentionally preserving only the icon; Discord allows one footer object, so later calls replace earlier text.
- Do not claim old Discord embeds cannot be updated when retrofitting embed text or branding; query the relevant channels via Discord REST and PATCH each target bot-authored message in place rather than re-sending duplicates.
- For ephemeral catalog previews, inventory the supplied archive first, reject unsafe ZIP paths, and map each screenshot to a numbered/labelled option without claiming that screenshots prove the number of in-game skin variants. Prefer verified public HTTPS images over attachments: mobile clients may retain file-backed replies after dismissal. Add the select menu to the detail embed, route its custom ID through both the central interaction dispatcher and the detail handler, validate selected values against a fixed allowlist before building the image URL, and update the existing ephemeral reply rather than sending another message. Keep an existing kit preview menu working when adding pet previews. If an attachment is unavoidable, pass `files` and `attachments: []` on `interaction.update` to replace the prior preview. Test the initial reply, every selection/image URL, invalid values, and the old menu without starting a second bot; verify HTTP content type for all images, then restart only the targeted PM2 bot and check status.
- Do not rely on `interaction.client.channels.cache.find()` alone to resolve destination logging channels (e.g. `donation-log`); uncached channels return `undefined`, silently skipping log delivery after external database insertions. Always resolve destination channels by explicit channel ID via `channels.fetch(id)` with cache fallback.
- If a public catalog panel needs only text/option changes, fetch its exact bot-authored message and PATCH it in place through Discord REST; read back ID, description, options, mention content and URL button. This avoids duplicate panel messages or fresh `@everyone` notifications.
