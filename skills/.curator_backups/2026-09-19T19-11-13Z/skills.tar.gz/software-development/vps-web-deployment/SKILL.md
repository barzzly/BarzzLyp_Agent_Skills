---
name: vps-web-deployment
description: Use when deploying web apps to Linux VPS. Deploy fullstack app with Nginx, MariaDB, PM2, and CI/CD.
---

# VPS Web Deployment

Standard procedure for deploying web applications (Node.js/Express, Vite/React, Fullstack) on a Linux VPS behind Nginx reverse proxy, process management (PM2/systemd), database provisioning, and Cloudflare DNS/SSL.

## Architecture & Standard Deployment Workflow

### 1. Repository & Location
- Place all web projects under the designated web root (e.g. `/home/<user>/Website/<project-name>`). Keep the home directory tidy.
- Clone or pull latest code:
  ```bash
  gh repo clone <repo> || git clone <url>
  ```
- Install dependencies and build production bundle:
  ```bash
  npm ci || npm install
  npm run build
  ```

### 2. Database Provisioning & Auto-Migrations (MariaDB/MySQL)
- Verify service status:
  ```bash
  sudo systemctl status mariadb
  ```
  If missing: `sudo apt update && sudo apt install -y mariadb-server`.
- Create dedicated database and restricted user:
  ```sql
  CREATE DATABASE IF NOT EXISTS <db_name> CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
  CREATE USER IF NOT EXISTS '<db_user>'@'localhost' IDENTIFIED BY '<strong_password>';
  GRANT ALL PRIVILEGES ON <db_name>.* TO '<db_user>'@'localhost';
  FLUSH PRIVILEGES;
  ```
- Import initial schema:
  ```bash
  sudo mariadb <db_name> < migrations/schema.sql
  ```
- Use an idempotent migration runner (`templates/migrate.cjs` -> `script/migrate.cjs`) to track executed files in `_migrations` table so subsequent pushes apply only new `.sql` migrations.
- Local dev connection: Never bind MariaDB to `0.0.0.0` or open port 3306 on UFW for remote development. Tunnel via SSH instead: `ssh -N -L 3307:127.0.0.1:3306 <user>@<vps_ip>`.

### 3. Environment & Security Configuration (`.env`)
- Populate `.env` with required runtime variables (`PORT`, `DB_*`, secrets, URLs).
- Generate secure secrets using `openssl rand -base64 48` or `crypto.randomBytes(48).toString('base64url')`.
- Restrict file permissions:
  ```bash
  chmod 600 .env
  ```

### 4. Process Management (PM2 & Systemd Persistence)
- Install PM2 in user space or global:
  ```bash
  npm install -g pm2
  ```
- Define `ecosystem.config.cjs`:
  ```javascript
  module.exports = {
    apps: [
      {
        name: "<app-name>",
        script: "dist/index.cjs",
        cwd: "<absolute-app-path>",
        env: {
          NODE_ENV: "production",
          PORT: 5000
        }
      }
    ]
  };
  ```
- Start app and persist state:
  ```bash
  pm2 start ecosystem.config.cjs
  pm2 save
  ```
- For reliable boot persistence without interactive prompt issues or script blockers, install a systemd service at `/etc/systemd/system/pm2-<user>.service`:
  ```ini
  [Unit]
  Description=PM2 process manager
  After=network.target

  [Service]
  Type=forking
  User=<user>
  LimitNOFILE=infinity
  LimitNPROC=infinity
  LimitCORE=infinity
  Environment=PATH=<npm-global-bin>:/usr/local/bin:/usr/bin:/bin
  Environment=PM2_HOME=/home/<user>/.pm2
  PIDFile=/home/<user>/.pm2/pm2.pid
  ExecStart=<pm2-path> resurrect
  ExecReload=<pm2-path> reload all
  ExecStop=<pm2-path> kill
  Restart=on-failure
  RestartSec=10

  [Install]
  WantedBy=multi-user.target
  ```
  Enable and load:
  ```bash
  sudo systemctl daemon-reload
  sudo systemctl enable pm2-<user>.service
  ```

### 5. Nginx Reverse Proxy Configuration
- Create `/etc/nginx/sites-available/<domain>`:
  ```nginx
  server {
      listen 80;
      server_name <domain>;

      location / {
          proxy_pass http://127.0.0.1:<port>;
          proxy_set_header Host $host;
          proxy_set_header X-Real-IP $remote_addr;
          proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
          proxy_set_header X-Forwarded-Proto https;
          proxy_http_version 1.1;
          proxy_set_header Upgrade $http_upgrade;
          proxy_set_header Connection "upgrade";
          proxy_read_timeout 300s;
      }
  }
  ```
- Enable and reload:
  ```bash
  sudo ln -sf /etc/nginx/sites-available/<domain> /etc/nginx/sites-enabled/
  sudo nginx -t
  sudo systemctl reload nginx
  ```

### 6. Cloudflare DNS & SSL Settings
- DNS record:
  - **Type**: `A`
  - **Name**: `<subdomain>` (or `@` for apex)
  - **IPv4**: `<vps_public_ip>`
  - **Proxy status**: Proxied (Orange Cloud)
- SSL/TLS encryption mode:
  - Set to **Full** (or **Flexible** if VPS listens only on port 80 HTTP).

### 7. Automated CI/CD via GitHub Actions (SSH Deploy on Push)
- Generate or ensure an SSH key pair exists (`~/.ssh/id_ed25519` and `id_ed25519.pub`).
- Append the public key to authorized keys:
  ```bash
  cat ~/.ssh/id_ed25519.pub >> ~/.ssh/authorized_keys && chmod 600 ~/.ssh/authorized_keys
  ```
- Store secrets in GitHub repo using `gh secret set`:
  ```bash
  gh secret set VPS_HOST --repo <owner>/<repo> --body "<vps_ip>"
  gh secret set VPS_USERNAME --repo <owner>/<repo> --body "<user>"
  gh secret set VPS_PORT --repo <owner>/<repo> --body "22"
  gh secret set VPS_SSH_KEY --repo <owner>/<repo> < ~/.ssh/id_ed25519
  ```
- Add workflow `.github/workflows/deploy.yml`:
  ```yaml
  name: Auto Deploy to VPS
  on:
    push:
      branches: [ main ]
  jobs:
    deploy:
      runs-on: ubuntu-latest
      steps:
        - name: Remote SSH deploy
          uses: appleboy/ssh-action@master
          with:
            host: ${{ secrets.VPS_HOST }}
            username: ${{ secrets.VPS_USERNAME }}
            key: ${{ secrets.VPS_SSH_KEY }}
            port: ${{ secrets.VPS_PORT || 22 }}
            script: |
              export PATH=$PATH:/home/<user>/.npm-global/bin:/usr/bin
              cd <app-path>
              git pull origin main
              npm ci --include=dev
              npm run db:migrate
              npm run build
              pm2 reload <app-name>
  ```

### 8. Network & Firewall Hardening (UFW)
- Only expose public web and SSH ports:
  ```bash
  sudo ufw default deny incoming
  sudo ufw default allow outgoing
  sudo ufw allow 22/tcp
  sudo ufw allow 80/tcp
  sudo ufw allow 443/tcp
  sudo ufw deny 5000/tcp
  sudo ufw deny 3306/tcp
  sudo ufw reload
  ```
- Verify default Nginx virtual host handles raw IP visits so internal applications only answer when requested by their exact domain name.

## Verification Gates

- Verify external references before reproducing UI: clone the supplied template repository, read its component and light/dark CSS, fetch live HTML/CSS, extract font/color/radius/layout tokens, and compare the deployed page at mobile and desktop viewports after each visual change; never infer a palette from memory or claim visual parity from an HTTP 200 alone.
- Treat the reference's page purpose as authoritative: reuse its layout grammar, card shape, spacing, and theme tokens, but replace converter-specific copy with the console's actual monitoring purpose; do not invent a process-flow sidebar merely because the reference has one.
- In light mode, audit every inherited dark token after the layout is added: headings, labels, button text, icons, status text, and logo treatments must have explicit readable light-theme colors; white text on white surfaces is a visual defect, not a cosmetic detail.
- Give branded login surfaces a readable wordmark or product name, not an unexplained single-letter placeholder; verify the mobile viewport because sparse cards expose weak branding immediately.
- For Discord bots, load every command file, deploy the complete command set to the intended guild, then query Discord's registered guild commands and compare names/counts before restarting PM2; `/join` and `/leave` may be from a separate command deployment and do not prove the full set is registered.
- Treat webhook tests as state-changing integration tests: use a clearly prefixed synthetic transaction, capture the returned message ID, read the exact Discord message back, confirm title/fields/status, and delete or mark the test artifact according to the test policy before declaring success.
- Never print API keys, bot tokens, expected secrets, or received secrets in production logs; log only request ID, outcome, and safe metadata because validation debugging can leak credentials into PM2 history.
- Query dedicated primary databases for game metrics: When querying Minecraft or external game metrics for web display (like PlayerPoints or LuckPerms), query the plugin's dedicated primary database table directly (e.g. `playerpoints_points` joined with `playerpoints_username_cache`) rather than relying purely on third-party leaderboard cache tables (like ajLeaderboards), which only capture players cached in local server files.
- Strip gratuitous decorative emojis from UI components (tabs, filter pills, leaderboard cards, headers); prioritize clean typography and functional standard icons over emoji clutter.
- **Mobile navigation must preserve primary actions**: never hide primary CTAs, login triggers, or user profile buttons exclusively inside off-canvas hamburger menus. Collapse them to compact, accessible icon buttons on the top bar. Language selectors should use explicit segmented pill toggles (`[ ID | EN ]`) with highlighted active states rather than standalone unstyled monospace badges.
- **Player Account Navigation (Modal Hub vs Dedicated Pages)**: Avoid cramming long, scrollable transaction histories or dense telemetry tables inside small navigation modals. Structure account modals as compact status hubs (avatar, platform badge, key metric chips) with explicit routing buttons leading to dedicated `/profile` (3D avatar/skin render, server connection details, rank perks) and `/transactions` (status filter tabs, search by ID/item, copyable invoice ID, checkout URLs) pages.
- **Discord Bot Information & Shop Panels (Ephemeral Detail Pattern & Native Custom Emojis)**:
  - When displaying server tier catalogs, ranks, or shop items in public Discord channels, avoid dumping long perk lists that clutter chat. Post a single, high-level overview embed listing tiers and prices with interactive UI components (`StringSelectMenuBuilder` and `ButtonBuilder`).
  - **Avoid Ephemeral File Attachments (Discord Dismiss Bug)**: Never attach raw file buffers/attachments (`files: [attachment]`) to ephemeral interaction replies (`ephemeral: true` / `flags: 64`). Discord mobile and desktop clients cache uploaded attachments locally, breaking the native "Dismiss message" / "Hapus pesan" client action so the message cannot be dismissed. Instead, serve images/icons from a permanent CDN or public web path (`https://store.<domain>/path.png`) via `.setThumbnail(url)` or `.setImage(url)`.
  - **Explicit Ephemeral Dismissal Component**: Always include an explicit `[ Tutup Pesan ]` button (`customId: '..._dismiss'`) on ephemeral detail embeds. Handle it via `await interaction.deferUpdate(); await interaction.deleteReply();` (with fallback to `interaction.update({ content: 'Pesan ditutup', embeds: [], components: [] })`) to guarantee instant one-tap dismissal across all Discord client versions.
  - **Spoiler Mention Tags for Channel Announcements**: Wrap mass mentions in spoiler tags (`|| @everyone ||`) outside the embed. This triggers server push notifications for the entire community while keeping the chat visually clean without exposed mention text.
  - **Native Animated Emojis vs Mobile Emoji Slop**: Strictly avoid generic system emojis in official Discord embeds. Use only the server's registered custom animated emojis (e.g. `<a:crown_animated:ID>` for headers and `<a:animatedarrowred:ID>` for perk bullets).
  - **Role Tier Segregation**: Never conflate `TIKTOK / YOUTUBE` (standard creator tier with minimum follower/content quotas) with `MEDIA` (partner/streamer tier requiring live concurrent viewer quotas). Keep them as distinct selectable tiers with separate permissions and demotion criteria.
  - **Minimal Footer Branding**: Embed footers in official panels must carry only clean organization branding (e.g. `Noesantara Network • Official Store`) paired with the bot avatar icon; eliminate superfluous timestamps, guide copy, or redundant URL strings at the bottom.
- **Leaderboard Gamemode Hierarchy**: In multi-gamemode Minecraft networks, leaderboards must expose the server/gamemode selector (e.g. ECO RPG, PVP SL, RP REBEL) hierarchically *above* specific stat metric tabs (Money, Coin, Playtime, Kills, Deaths). Each server tracks a distinct subset of plugins and stats (e.g. PvP servers track only combat stats, while RPG servers track economy, skills, and playtime). Switching servers must dynamically update the available metric categories and reset active selection to avoid displaying empty or invalid stats.

## Pitfalls & Core Rules

- **Non-Interactive SSH PATH in GitHub Actions**: Non-interactive SSH sessions spawned by CI runners do not load `.bashrc` or user profile PATH customizations. If `pm2` was installed via `npm install -g` into user space (`~/.npm-global/bin`), the deployment script will crash with `pm2: command not found`. Always export the explicit user npm bin directory in the deploy script (`export PATH=$PATH:/home/<user>/.npm-global/bin:/usr/bin`).
- **Cloudflare HTTPS Protocol Header**: When Nginx receives traffic on port 80 behind Cloudflare SSL, `$scheme` is `http`. If Nginx forwards `$scheme` instead of `https`, frameworks with `trust proxy` enabled will issue cookies without the `Secure` flag or reject HTTPS-only sessions, causing silent authentication redirects and broken login flows. Always force `proxy_set_header X-Forwarded-Proto https;` or use a map on `$http_x_forwarded_proto`.
- **Pre-check Port Conflicts**: Always inspect existing listeners (`ss -tulpn`) before picking an application port to prevent binding collisions with existing containers or Node/Python daemons.
- **Production Build Flags**: On hosts with `NODE_ENV=production`, run `npm ci --include=dev` or `npm install` before running the build step, because build toolchains (Vite, TSX, esbuild) reside in `devDependencies` and are stripped by default in production installs.
- **Claude Code Router Model Override**: Global `ANTHROPIC_DEFAULT_OPUS_MODEL` in settings can silently redirect a custom `--model` flag. Override routing cleanly per-invocation by passing `--settings '{"model":"<requested_id>","env":{"ANTHROPIC_DEFAULT_OPUS_MODEL":"<requested_id>"}}'`.
- **Frontend Dead Code & Component Pruning**: Boilerplate UI templates (like unreferenced shadcn components) bloat bundle chunks and increase compile times. Scripting cross-import reference checks across source files before production deployment cuts bundle size significantly (e.g. dropping CSS from 151KB to 102KB) without regressing active components.
- **Database Security for Remote Dev**: Exposing database ports (3306/5432) to public IP creates constant attack surfaces for credential brute-force. Keep database bound to `127.0.0.1` and firewalled (`ufw deny 3306/tcp`); connect remote development environments exclusively through encrypted SSH port-forwarding tunnels (`ssh -N -L <local_port>:127.0.0.1:<remote_port> <user>@<host>`).
- **Avoiding Subshell Self-Termination with `pkill -f`**: Executing `pkill -f "<pattern>"` inside automated scripts or wrapper commands (such as runner subshells or `eval`) matches the executing runner's own command string in `ps`, sending SIGTERM to itself and aborting execution prematurely. Prevent self-termination by bracket-escaping the regex pattern (e.g. `pkill -f "[p]attern"` so the regex argument does not match itself) or targeting process supervisors directly (`tmux kill-session -t <name>`, `pm2 stop <app>`).
- **Headless Verification of Protected Admin Portals**: When running automated QA or capturing full dashboard evidence for protected admin pages without interactive login prompts, generate a transient cryptographic JWT using the application's local `JWT_SECRET`, inject the authentication and CSRF cookies directly via CDP (`Network.setCookie`), and prime any client-side persistence (e.g. Zustand `admin-storage` in `localStorage`) before navigation. For full-height dashboard screenshots, set high-resolution bounds via CDP `Emulation.setDeviceMetricsOverride(width=1440, height=1200)` and capture with `Page.captureScreenshot(captureBeyondViewport=True)`.
- **Cloudflare 502 Bad Gateway Triaging (Dead Upstream Listener)**: When Cloudflare serves 502 Bad Gateway while the host, Nginx, and public ports (80/443) are healthy, the failure is almost always an unlistening local reverse-proxy upstream port. Compare Nginx vhost `proxy_pass` against active listeners (`ss -tulpn | grep :<port>`), then verify supervisor status (`pm2 list`). If the supervisor daemon crashed or stopped, restore with `pm2 resurrect`, verify the local port returns 200 via `curl -sI -H "Host: <domain>" http://127.0.0.1:<port>`, and persist with `pm2 save`.
- **PM2 Systemd Service Auto-Recovery**: Omitting `Restart=on-failure` in `pm2-<user>.service` leaves the entire process manager dead if the daemon exits unexpectedly or gets killed. Always include `Restart=on-failure` and `RestartSec=10` in the systemd unit so daemon drops automatically trigger `pm2 resurrect` without leaving upstream reverse proxies returning 502.
- **Rollback Procedure with Active Push CI/CD**: When rolling back a deployed web application to a specific earlier commit where GitHub Actions triggers on push to `main` (`git pull origin main`):
  1. Create a local backup branch before altering HEAD (`git branch backup-<topic>`) to retain uncommitted or dropped commits.
  2. Reset local tracking branch: `git reset --hard <target_commit>`.
  3. Force-push to remote: `git push --force origin main`. Aligning the remote ensures the CI/CD runner runs without branch divergence or merge conflict.
  4. Track the automated deploy job with `gh run watch <run_id>` until completion.
  5. Verify listening ports (`ss -tulpn | grep :<port>`), save the supervisor state (`pm2 save`), and test upstream responses via local and public HTTPS cURL probes.
- **Background Worker & Bot Staging in PM2**: When hosting standalone background services (e.g. Discord bots, message consumers) alongside web apps, wrap file configs (`require('./config.json')`) in try/catch blocks with fallback to `process.env`. Check required credentials (e.g. `TOKEN`) before calling client connection routines and halt with a distinct error if missing, preventing PM2 from entering tight crash-restart loops on unconfigured processes. Persist supervisor state via `pm2 save` only once the service successfully starts and validates.
- **Private Operations Console Deployment**: Bind admin consoles to `127.0.0.1`, expose them only through an Nginx hostname, and put authentication, secure HttpOnly/SameSite cookies, CSRF checks, login throttling, strict CSP, `X-Frame-Options: DENY`, and allowlisted PM2 actions in the app because a public control port turns process management into a remote command surface. Generate console secrets locally and keep them out of Git; verify the console process, loopback response, Nginx config, DNS resolution, and public HTTPS response separately before claiming the hostname is live. If the brief says monitor-only, remove process-control endpoints and buttons rather than merely hiding them in the UI. For branded login screens, use the supplied asset itself in the markup and verify its public URL returns `Content-Type: image/png` plus the PNG magic bytes; do not accept a 200 response that is actually the SPA HTML fallback.
- **Static Asset Routing Order**: Register `express.static(publicDir)` before the catch-all SPA route, then verify representative assets with `curl -I` and inspect their body signature; otherwise `/favicon.png` and logos can receive `index.html`, producing browser broken-image icons while the page itself returns 200.
- **Domain Cutover Prerequisites**: Treat Nginx installation and DNS as separate deployment gates. If root authorization is unavailable, commit the vhost template and run the app on loopback, but report Nginx/DNS as unfinished rather than calling deployment complete; Cloudflare cannot reach an origin hostname that has no resolving DNS record.
- **Repository Hygiene for Generated Analysis**: Keep scrape exports, raw Discord messages, local scripts, `.env` files, and console runtime code out of bot repositories unless explicitly requested; add them to `.gitignore` before committing because operational data and secrets do not belong in source history. Commit only production console code, deployment templates, and intended config changes, then verify `git show --stat HEAD` and remote branch state.
- **Indonesian Community Donation Log Scraping & Currency Edge Cases**: When parsing community donation logs from Discord embeds or transaction receipts:
  - **Discord Log Evolution (Embeds vs Plain Content)**: Early Discord logs or manual staff entries are frequently posted as raw plain text/code blocks directly inside `message.content` rather than structured `message.embeds`. Scraping exclusively from `embeds` silently drops legacy transactions. Always parse both `message.embeds` (description/fields) and `message.content`. Legacy logs also frequently omit explicit `STATUS` fields; treat logs in dedicated logging channels as successful by default unless explicitly tagged with negative statuses (`TOLAK`, `BATAL`, `PENDING`, `REJECT`).
  - **Player Name Normalization & Bedrock Dot Preservation**: Preserve leading dots (`.`) on Bedrock player usernames (`.TherryVa`, `.MarksThel`, `.JambuMerahh`) because stripping them alters the player's valid gamertag. Clean up irregular whitespace after the dot (`. TherryVa` -> `.TherryVa`) and map known staff typos or repeated character variations (`Leciiii`/`lecii` -> `Leciii`), but never strip the dot from canonical Bedrock names.
  - **Cents & Suffix Disambiguation**: Watch for decimal cent strings (`,00` or `.00` at the end like `120.000,00`), which inflate amounts 100x if purely stripping non-digits; strip terminal decimal cents before digit extraction.
  - **Redundant Thousand Notation**: Watch for redundant thousand notation (e.g. `20.000k` or `5.000k`), where both `.000` and `k` are specified; treat as thousands, not millions.
  - **Shorthand Values**: Watch for shorthand values `< 1000` without unit (e.g. `120` or `160` for ranks, `430` for bundles); treat as thousands (`120k`, `160k`).
  - **Virtual Currency Filtering**: Differentiate real currency donations from ingame virtual currency purchases (e.g. `HARGA: 105 COIN`).
  - **Shared / Couple Donation Splits**: Transactions listing multiple players joined by emojis (`🩷`, `💝`, `🌈`, `💕`) or conjunctions (`&`, `+`, ` dan `) represent joint purchases. Split the transaction amount evenly (50/50 for two players) and credit each player with their proportionate share and transaction count rather than retaining composite names.
  - **Spreadsheet & Excel Localization Traps**: Delivering comma-separated CSV (`.csv`) to users in Indonesian or European locales causes spreadsheet software (Excel, WPS) to dump the entire line into Column A because those locales use `;` as the list separator and `,` as the decimal mark. Always generate native `.xlsx` workbooks using `openpyxl` (runnable via `uv run --with openpyxl python ...`) with explicit column typing, auto-fitted column widths, and currency formatting (`"Rp "#,##0`). When raw CSV is required, provide a semicolon-delimited version with UTF-8 BOM (`encoding="utf-8-sig"`).
- **Client-Side Bulk Image Resizing & Batched Ingestion**: When implementing multi-image upload in admin portals (e.g. 50–100 photos):
  - Do not artificially clamp raw client-side file pickers to small sizes (like 10MB) if images are scaled down via `<canvas>` locally before upload; raw camera and mobile photos regularly exceed 12–25MB. Allow a higher raw file ceiling (50MB) and downscale to WebP client-side.
  - Process canvas resizing sequentially or with bounded concurrency while displaying a real-time progress counter (`X/total`). Unbounded `Promise.all` across dozens of high-res image files exhausts browser memory and crashes the tab.
  - Dispatch uploads in small HTTP chunks (e.g. 5 photos per request) with sequential execution. This avoids HTTP 413 Payload Too Large errors on reverse proxies and stays well within Express body limits and database `max_allowed_packet` constraints.
- **Interactive Action Elements Inside Drag / Swipe Carousels**:
  - Drag tracks that apply `isDragging ? "[&_*]:pointer-events-none cursor-grabbing" : "cursor-grab"` cancel child click events if `isDragging` activates on `onMouseDown` or `onTouchStart` before the browser's `click` event fires.
  - Always guard container drag handlers: `if ((e.target as HTMLElement).closest("a, button")) return;` in both `onMouseDown` and `onTouchStart`.
  - On the interactive child element, attach `onMouseDown={(e) => e.stopPropagation()}` and `onTouchStart={(e) => e.stopPropagation()}`, and provide an explicit `onClick` fallback (`window.open(url, "_blank")` for external links).
  - In illustrated profile or team cards, position link buttons underneath the role description copy on the content side of the card, never overlapping the character's feet or graphics.
- **Historical Donation Merging & Leaderboard Truth**:
  - Never compute player donation sums or top donor positions (`#1`, `#2`) solely against empty or fresh web `transactions` database tables when a historical log exists.
  - **Prevent Double-Counting When Seeding DB**: Once historical Discord transactions are fully imported into the primary database, ensure leaderboard and profile merge helpers use the database query directly as the authoritative source of truth. Unconditionally adding static historical logs (`DONATORS_DATA`) to database sums duplicates every player's total spend (e.g. 1.8M becomes 3.6M). Treat static lists strictly as offline/empty fallbacks.
  - Assign a donor ranking place only when `totalDonated > 0`; otherwise, display a neutral unranked placeholder (`-`) to avoid showing deceptive ranks for non-donating players.
- **Client & CDN Static Asset Replacement Cache-Busting**:
  - When updating or replacing existing image assets (banners, logos, rank textures) with the same filename, client browsers and social crawlers aggressively serve stale cached files from disk cache.
  - Always append an explicit cache-busting query parameter (e.g. `image: '/gamemodes/ecorpg.webp?v=3'`, `og:image?v=banner'`) or alter the public asset subpath in code and HTML meta tags so clients download the new graphic immediately without requiring manual cache clearing.
- **Minecraft Plugin Migration to MySQL & Live Web Profile Integration (AuraSkills/AureliumSkills)**:
  - When migrating player progression data (e.g. RPG skills) from local storage (YAML/SQLite) to MySQL on Pterodactyl/Linux:
    1. Create an offline snapshot via in-game/console command (`/skills backup save` producing e.g. `backup-<date>.yml`).
    2. Update plugin `config.yml` (`sql.enabled: true`, `sql.type: mysql`, database host, port, credentials) and restart the server to trigger automated DDL table creation (`auraskills_users`, `auraskills_skill_levels`).
    3. Run `/skills backup load <backup_file>.yml` or `/skills migrate sqlite mysql` from the console to batch-populate MySQL records without loss.
    4. Connect web backends via connection pools, resolving player UUIDs against LuckPerms (`luckperms_players.uuid`) or PlayerPoints (`playerpoints_username_cache.uuid`) to match `auraskills_users.player_uuid` and display live levels, XP progression, and power ranks dynamically on web profiles.
- **Syncing Discord Donation Receipts to Webstore Database (`transactions`) with Idempotent Deterministic Order IDs**:
  - When populating historical webstore transactions from a Discord logging channel:
    1. **Scrape All Channel Messages (Human Chat & Bot Embeds)**: Query Discord REST API (`/channels/<id>/messages?limit=100&before=<id>`) to retrieve the full channel history. Never assume logs exist exclusively inside bot embeds (`message.embeds`); historical staff entries or manual donation confirmations are often posted as plain-text codeblocks directly in `message.content`. Parse both sources so legacy transactions are not dropped.
    2. **Deterministic UUID Order IDs**: Instead of random UUIDs (which create duplicate rows on re-runs), generate deterministic UUIDs (e.g. UUID v5 based on `noesantara-donation-${msg.id}`). Discord snowflake message IDs are globally unique, guaranteeing that each transaction receives a permanent, collision-free standard 36-char Order ID (e.g. `9d25402e-fe6f-443d-9680-bd5dfc548ca1`). For couple/shared purchases (e.g. `UserA + UserB`), split 50/50 and append deterministic indices (`...-${msg.id}-1`, `...-${msg.id}-2`).
    3. **Idempotent Ingestion & Table Reset**: If previous imports produced cluttered or partial data, truncate the target table (`TRUNCATE TABLE transactions`) before executing a clean full ingestion, or use `INSERT ... ON DUPLICATE KEY UPDATE` for incremental additions.
    4. **Transaction Schema Mapping**: Parse Discord ISO 8601 timestamps to `paid_at`, `delivered_at`, and `created_at`; serialize products into standard JSON array format (`[{"name": itemName, "quantity": 1, "price": price}]`); set `status: 'success'` and `payment_method: 'manual_discord'`.
    5. **Flexible Webstore User Matching (Case-Insensitivity & Bedrock Dot Queries)**: When serving user transactions on `/transactions` or account modals, rigid exact matching (`WHERE username = ?`) breaks when users log in with different casing (e.g. `LECIII` vs `Leciii`) or Bedrock players log in with or without the leading dot (`.TherryVa` vs `TherryVa`). Always match case-insensitively across name variants:
       ```sql
       WHERE LOWER(username) = LOWER(?)
          OR LOWER(username) = LOWER(?)
          OR LOWER(username) = LOWER(?)
       ```
       passing raw input, dot-stripped, and dot-prepended forms, with a generous `LIMIT 200`.
    6. **Preserve Bot-Generated `ID TRX` in Scraper**: When a Discord bot creates a manual donation via `/donation` with an explicit identifier (`ID TRX : MAN-...`), make the Discord channel scraper check for existing `ID TRX` before falling back to a deterministic UUID. This guarantees that real-time bot insertions and subsequent periodic scraping runs share the exact same primary key, preventing duplicate rows via `ON DUPLICATE KEY UPDATE`.
    7. **Robust Currency Parsing in Bot Modal Inputs**: Never parse currency input using naive non-digit stripping (`replace(/[^0-9]/g, '')`), because staff frequently enter shorthand like `50k`, `100k`, or `50` (thousands). Stripping non-digits converts `50k` into `50` (Rp 50 instead of Rp 50.000). Always normalize `k` suffixes, strip terminal decimal cents (`,00`), and interpret `< 1000` as thousands.
    8. **Couple Donation Regex Trap (Heart Emojis & Conjunctions)**: When splitting joint/couple donations from Discord logs, splitting only on `+` or `&` drops or mis-attributes donations formatted with heart emojis (`🩷`, `❤️`, `💝`, `🌈`, `💕`, `💖`, `💘`) or language conjunctions (` dan `). A naive split leaves compound names intact or drops transactions entirely, skewing total revenue by millions (e.g. dropping 12.4M from 83M down to 70M). Use a comprehensive multi-delimiter regex: `/(?:\s*[🩷❤️💝🌈💕💖💘&+]+\s*|\s+dan\s+)/i`.
    9. **Production Environment Hardening Checklist for Express/Vite SPAs**: Before switching `NODE_ENV=production` on an active web deployment:
       - Ensure Helmet CSP directives drop `'unsafe-eval'` (only used for Vite HMR) while keeping CDNs (Cloudflare insights, Google fonts, skin APIs) allowlisted.
       - Enforce HSTS with 1-year maxAge and `Secure: true` on session cookies behind Nginx with `X-Forwarded-Proto https`.
       - Rebuild the production client bundle and reload PM2 using `--update-env` (`pm2 reload <app> --update-env`) to ensure worker processes pick up the environment change without manual process termination.
    10. **Client-Side Trust Device & Session Auto-Expiry (Watchdog Pattern)**:
       - In client-side SPAs using persisted stores (e.g. Zustand `persist` to `localStorage`), user sessions persist indefinitely by default, posing security risks on shared or public devices.
       - Record `loginAt: Date.now()` on login and persist it via `partialize`. Define an explicit timeout window (e.g. `USER_SESSION_MS = 60 * 60 * 1000` for 1 hour).
       - Expose `checkSession()` that computes `Date.now() - loginAt > USER_SESSION_MS`, triggers `logout()`, clears the shopping cart, and fires the logout event when expired.
       - Invoke `checkSession()` in the store's `onRehydrateStorage` callback so tab reloads or reopening after the expiry window immediately invalidate the session.
       - Mount an active watchdog interval in the application root (`App.tsx`) checking every 30 seconds and on `window.addEventListener("focus", check)` so background tabs or idle sessions terminate cleanly without requiring user action.
    11. **Social Media Link Preview & OpenGraph Cache-Busting (WhatsApp / Discord / Twitter)**:
       - Crawlers for social apps (especially WhatsApp and Facebook) aggressively cache `og:image` targets by URL indefinitely; replacing an image asset on disk with the same filename leaves link previews frozen on obsolete graphics.
       - Provide both a 1:1 square preview (`og-image.png` / 512x512 or square artwork for WhatsApp chat cards) and a 1.91:1 landscape card (`og-banner.png` / 1200x630 for Twitter `summary_large_image` and Discord embeds).
       - Add an explicit cache-busting query parameter across all OpenGraph tags (`<meta property="og:image" content="https://<domain>/og-image.png?v=<tag>" />`), paired with `og:image:secure_url`, `og:image:type`, `og:image:width`, and `<link rel="image_src" ...>`.
       - Verify using `curl -sI https://<domain>/og-image.png` that the static asset route returns `Content-Type: image/png` and HTTP 200 rather than falling through to the SPA `index.html`.
    12. **Seamless Backdrop Alpha Fading (Eliminating Hard Bottom Edges)**:
       - When header or hero backdrops display high-contrast or high-opacity images (e.g. `opacity-75`) blending into light solid background content, standard background color gradient overlays frequently leave a noticeable horizontal clipping line at the bottom of the container.
       - Eliminate hard edges by layering CSS `mask-image: linear-gradient(to bottom, black 50%, transparent 100%)` directly on the image element and terminating the background color gradient earlier (`to-85%` reaching `#FEFEFE`), allowing alpha transparency to hit 0 before container bounds.
